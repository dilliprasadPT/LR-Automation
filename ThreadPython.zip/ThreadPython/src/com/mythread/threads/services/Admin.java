package com.mythread.threads.services;

import java.util.Random;

import com.mythread.threads.vo.StudentVo;

public class Admin {
	public StudentVo generateId(StudentVo svo) {
		svo.setsId(""+new Random().nextInt());
		return svo;
	}

}
