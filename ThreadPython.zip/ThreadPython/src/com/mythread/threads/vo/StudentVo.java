package com.mythread.threads.vo;

public class StudentVo {

private String sName;
private String sId;
private int sAge;
private String sEmail;

public String getsName() {
	return sName;
}
public void setsName(String sName) {
	this.sName = sName;
}
public String getsId() {
	return sId;
}
public void setsId(String sId) {
	this.sId = sId;
}
public int getsAge() {
	return sAge;
}
public void setsAge(int sAge) {
	this.sAge = sAge;
}
public String getsEmail() {
	return sEmail;
}
public void setsEmail(String sEmail) {
	this.sEmail = sEmail;
}
@Override
public String toString() {
	return "StudentVo [sName=" + sName + ", sId=" + sId + ", sAge=" + sAge + ", sEmail=" + sEmail + "]";
}

}
