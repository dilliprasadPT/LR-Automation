package com.mythread.threads;

import java.util.ArrayList;

import com.mythread.threads.services.Admin;
import com.mythread.threads.vo.StudentVo;

public class StudentThread implements Runnable {
public StudentThread() {
		super();
		// TODO Auto-generated constructor stub
	}

int sIn;
int sOut;
StudentVo svo[]; 
ArrayList<StudentVo> sList=new ArrayList<>();


	public StudentVo[] getSvo() {
	return svo;
}

public void setSvo(StudentVo[] svo) {
	this.svo = svo;
}

	public StudentThread(int sIn,int sOut) {
		// TODO Auto-generated constructor stub
		this.sIn=sIn;
		this.sOut=sOut;
	}
		
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=sIn;i<sOut;i++) {
			System.out.println("------------->"+Thread.currentThread().getName());
			StudentVo svObj=new Admin().generateId(svo[i]);
			//System.out.println(svObj);
			sList.add(svObj);
		}
	}
/*	public ArrayList<StudentVo> getStudentList() {
		return sList;
	}*/

	public ArrayList<StudentVo> getsList() {
		return sList;
	}

	public void setsList(ArrayList<StudentVo> sList) {
		this.sList = sList;
	}

}
