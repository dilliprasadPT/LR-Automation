package com.mythread.threads.client;

import com.mythread.threads.StudentThread;
import com.mythread.threads.vo.StudentVo;

public class StudentThreadClient {

	public StudentThreadClient() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		int countThread=10;
		
		int totalStudents=1000;
		StudentVo svo[]=new StudentVo[totalStudents];
		
		for(int j=0;j<totalStudents;j++) {
			StudentVo svoNew=new StudentVo();
			svoNew.setsAge(20+j);
			svoNew.setsEmail("prasad"+j+"@gmail.com");
			
			//svoNew.setsId(sId);
			svoNew.setsName("Prasad"+j);
			svo[j]=svoNew;
			svoNew=null;
		}
		
		
		int in=0;
		int out=0;
		
		StudentThread [] sThread=new StudentThread[countThread];
		System.out.println("Started");
		Thread.currentThread().setName("PavanKalyan");
		String thName=Thread.currentThread().getName();
		System.out.println();
		for(int i=0;i<sThread.length;i++) {
			out=svo.length/10;
			in=i*out;
			sThread[i]=new StudentThread(in,out+in);
			sThread[i].setSvo(svo);
			
			Thread t=new Thread(sThread[i]);
			System.out.println("thName:"+thName);
			t.start();
			System.out.println("thName:"+t.getName());
		t.join();
			//System.out.println("Thrad resumed");
			for(StudentVo svoGen:sThread[i].getsList()) {
				System.out.println(svoGen);
			}
			
		}
		
	System.out.println("Ended");
	}

}
