from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup as bs
import requests
import lxml
import time


chrome_options=Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--incognito")
import os
driver_path="../../Drivers/chromedriver.exe"
#chrome_options=chrome_options

driver=webdriver.Chrome(executable_path=driver_path,chrome_options=chrome_options)
driver.get("https://rolls-royce.leankit.com/Account/Membership/Login")
driver.maximize_window()
element1=driver.find_element_by_id("userName")
element1.send_keys("Amey.Patil@quest-global.com")
element2=driver.find_element_by_id("password")
element2.send_keys("Quest=1234")
driver.find_element_by_class_name("login-rememberLabel").click()
driver.find_element_by_id("Login").click()
driver.find_element_by_class_name("boardList-thumbnail").click()
element_url=driver.current_url
print(element_url)
time.sleep(5)
soup=bs(driver.page_source,'lxml')
#print(soup.select("div"))
#print("********************************************")
#print(soup)

file=open("baord.txt","w+")
file.write(soup.prettify())

#print(soup.find("div"))

"""div= soup.find("div", { "class" : "board-lane" })
children = div.findChildren("div" , recursive=False)
for child in children.find("div", { "class" : "card-background"} ):
    print(child)
#    asd = div.find("div",{"class" : "card-background"})"""
asd=soup.find("div",class_ ="board-lane")
#children=asd.findChildren("div",recursive=True)
children=asd.findChildren("div",recursive=True)
print(children[1])
for div1 in children :
    print("*********************************")
    #print(div1)
    carddiv = div1.find("div",class_ ="card-background")
    #print(carddiv.title)
    print(carddiv.get_text())


    #print(carddiv.div)
    #print(len(carddiv))
    #print(type(carddiv))
    """for i in carddiv:
        tilte=i.find_all("div",="")"""

    #asd=driver.find_element_by_class_name("card-background").text
    #print(asd)
    #print("****************************")



#print(soup.find_all("div",{"class":"board-lane"}))
#print(soup.prettify())
#print(soup.find(class_="board-laneContainer"))
#driver.find_element_by_class_name("card").click()






""""for div1 in children :
    print("*********************************")
    #print(div1)
    carddiv = div1.find_all("div",class_ ="card-background")
    print(len(carddiv))
    print(type(carddiv))
    title=carddiv[0]
    print(title)
    title1 = carddiv[1]
    print(title1)
    #asd=driver.find_element_by_class_name("card-background").text
    #print(asd)
    print("****************************")"""""




