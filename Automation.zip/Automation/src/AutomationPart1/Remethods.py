from bs4 import BeautifulSoup
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import html5lib
import lxml
import time

chrome_options=Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--incognito")
driver_path="../../Drivers/chromedriver.exe"
chrome_options=chrome_options

driver=webdriver.Chrome(executable_path=driver_path,chrome_options=chrome_options)
driver.get("https://rolls-royce.leankit.com/Account/Membership/Login")
driver.maximize_window()
element1=driver.find_element_by_id("userName")
element1.send_keys("Amey.Patil@quest-global.com")
element2=driver.find_element_by_id("password")
element2.send_keys("Quest=1234")
driver.find_element_by_class_name("login-rememberLabel").click()
driver.find_element_by_id("Login").click()
driver.find_element_by_class_name("boardList-thumbnail").click()
element_url=driver.current_url
print(element_url)
time.sleep(3)
#r=requests.get(element_url)
soup = BeautifulSoup(driver.page_source, 'html5lib')
print(soup.prettify())

card_data=[]
table=soup.find("div",class_="board-laneContainer")

for row in table.find_all('div',class_="card-background"):
    data = {}
    data["Con/DpNo"]=row.div.text
    title=row.get('title')
    title=title.split(':')
    data["Type"]=title[0]
    data["titel"]=title[1]
    print(data)
for row in table.findAll('div',class_="laneCardContainer-card"):
    data1={}
    data1['cardID']=row.get("data-clipboard-text")
    print(data1)
for row in table.findAll('div',class_="laneHeader"):
    data2={}
    data2["LeanID"]=row.get("data-clipboard-text")
    print(data2)
for row in table.findAll('div',class_="cardIcons-icon--cardSize"):
    data3={}
    size=row.get('title')
    size=size.split(':')
    data3['Cardsize']=size[1]
    print(data3)
for row in table.findAll('div',class_="cardIcons-icon--calendar"):
    data4={}
    date=row.get('title')
    date = date.split(':')
    data4['PlanedFinishDate']=date[1]
    print(data4)
#id="card-details-11-externalSystemUrl"
for row in table.findAll('input',id="card-details-11-externalSystemUrl"):
    data5={}
    data5["Forumpass_Link"]=row.get('value')
    print(data5)


driver.quit()

