from selenium import webdriver
import urllib3
from bs4 import BeautifulSoup
import requests
import lxml

chrome_path = "../../Drivers/chromedriver.exe"


driver = webdriver.Chrome(executable_path=chrome_path)
driver.maximize_window()
driver.get("https://rolls-royce.leankit.com/Account/Membership/Login")
username=driver.find_element_by_id("userName").send_keys("Amey.Patil@quest-global.com")
password=driver.find_element_by_id("password").send_keys("Quest=1234")
submit=driver.find_element_by_id("Login")
submit.click()
block=driver.find_element_by_xpath("//a[@ title='RRD EO-3 / EO-4 Concession Stream']").click()
driver.implicitly_wait(20)


asd="BR725 HE3392 ESN 65397  ML 6/2"
card=driver.find_element_by_xpath("//div[contains(@title,'"+asd+"')]").click()
link=driver.find_element_by_xpath("//input[@class='inputText cardExternalLink-linkUrl']")
print(link.get_attribute("value"))


cardurl=driver.current_url
#//div[@class='tetheredSelect-iconOption']//span[@class='tetheredSelect-valueText']
soup = BeautifulSoup(driver.page_source,'lxml')
print(soup.prettify())
lean=soup.findAll("div",class_="cardDetails-priority")
for row in lean:
    print(row.get('title'))