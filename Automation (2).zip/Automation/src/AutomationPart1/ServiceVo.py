class ServiceVo:

    def __init__(self,Con,Type,title,cardID,Cardsize,PlanedFinishDate):
        self.Con=Con;
        self.Type=Type;
        self.title=title
        self.cardID=cardID
        self.Cardsize=Cardsize
        self.PlanedFinishDate=PlanedFinishDate

    def get_Con(self):
        return self.Con
    def set_Con(self,Con):
        self.Con=Con
    def get_Type(self):
        return self.Type
    def set_Type(self,Type):
        self.Con=Type
    def get_title(self):
        return self.title
    def set_title(self,title):
        self.Con=title
    def get_cardID(self):
        return self.cardID
    def set_cardID(self,cardID):
        self.Con=cardID
    def get_Cardsize(self):
        return self.Cardsize
    def set_Cardsize(self,Cardsize):
        self.Con=Cardsize
    def get_PlanedFinishDate(self):
        return self.PlanedFinishDate
    def set_PlanedFinishDate(self,PlanedFinishDate):
        self.Con=PlanedFinishDate