import pika

connection = pika.BlockingConnection(pika.ConnectionParameters("172.18.50.39"))
channel = connection.channel()
channel.queue_declare(queue='hello')


def callback(ch, method, properties, body):
    print("[x] recived%" +str(body))


channel.basic_consume(callback, queue="hello", no_ack=True)
print("waiting for mesage")

channel.start_consuming()
connection.close()

