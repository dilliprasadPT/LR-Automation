import pika
class rabbitmouse:
    connection = pika.BlockingConnection(pika.ConnectionParameters("172.18.50.39"))
    channel = connection.channel()
    channel.queue_declare(queue="hello")
    channel.basic_publish(exchange='', routing_key='hello', body="hello world")
    print("[x] sent hello world")
    connection.close()
